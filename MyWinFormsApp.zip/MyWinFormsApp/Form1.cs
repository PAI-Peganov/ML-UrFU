using System.Text.RegularExpressions;


namespace MyWinFormsApp
{
    public partial class Form1 : Form
    {
        private TextBox inputTextBox;
        private Label resultLabel;
        private Label debugLabel;
        public Form1()
        {
            InitializeComponent();
            CreateControlsInstance();
        }

        private void CreateControlsInstance()
        {
            Text = "Проверка палиндрома";
            Size = new Size(500, 250);
            StartPosition = FormStartPosition.CenterScreen;

            Label inputLabel = new Label
            {
                Text = "Введите слово или предложение:",
                Location = new Point(20, 20),
                Size = new Size(200, 20),
            };

            inputTextBox = new TextBox
            {
                Location = new Point(20, 45),
                Size = new Size(440, 20),
                Font = new Font("OpenSans", 10)
            };
            inputTextBox.TextChanged += ChangeTextBoxState;

            resultLabel = new Label
            {
                Text = "Ожидание ввода:",
                Location = new Point(20, 80),
                Size = new Size(440, 30),
                Font = new Font("OpenSans", 10, FontStyle.Bold)
            };

            debugLabel = new Label
            {
                Text = "Строка откладки: готов к работе",
                Location = new Point(20, 120),
                Size = new Size(440, 40),
                Font = new Font("OpenSans", 9),
                ForeColor = Color.Red

            };

            Controls.AddRange(
            [
                inputLabel,
                inputTextBox,
                resultLabel,
                debugLabel
            ]);
        }

        private bool IsPalindrome(string input)
        {
            string normInput = Regex.Replace(input.ToLower(), @"\s", "");
            char[] charArray = normInput.ToCharArray();
            Array.Reverse(charArray);
            string reversedInput = new string(charArray);
            return normInput == reversedInput;
        }

        private int CountLetters(string input)
        {
            Regex regex = new Regex(@"[A-Za-zА-Яа-яЁё]");
            return regex.Matches(input).Count;
        }

        private bool IsValidInput(string input)
        {
            Regex regex = new Regex(@"^[A-Za-zА-Яа-яЁё\s]*$");
            return regex.IsMatch(input);
        }
        // logic
        private void ChangeTextBoxState(object sender, EventArgs e)
        {
            string input = inputTextBox.Text;

            if (!IsValidInput(input))
            {
                debugLabel.Text = "Строка отладки: Обнаружены недопустимые символы! Разрешены только буквы и пробелы.";
                resultLabel.Text = "Некорректный ввод";
                resultLabel.ForeColor = Color.Red;
                return;
            }

            if (string.IsNullOrWhiteSpace(input))
            {
                debugLabel.Text = "Строка откладки: готов к работе";
                resultLabel.Text = "Ожидание ввода:";
                resultLabel.ForeColor = Color.Black;
                return;
            }

            debugLabel.Text = $"Строка откладки: Длина: {input.Length}, Символов (без пробелов): {CountLetters(input)}";

            if (IsPalindrome(input))
            {
                resultLabel.Text = "Это палиндром!";
                resultLabel.ForeColor = Color.Green;
            }
            else
            {
                resultLabel.Text = "Это не палиндром!";
                resultLabel.ForeColor = Color.Red;
            }
        }
    }
}
